import React, { useEffect, useRef, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import logo from "../assets/logo.png";
import { getGenres, getCountries } from "../services/tmdbService";

export default function Navbar() {
  const [genres, setGenres] = useState([]);
  const [countries, setCountries] = useState([]);
  const [isGenreOpen, setGenreOpen] = useState(false);
  const [isCountryOpen, setCountryOpen] = useState(false);

  // Ref cho dropdown thể loại
  const genreDropdownRef = useRef(null);

  useEffect(() => {
    getGenres().then(setGenres).catch(() => setGenres([]));
    getCountries().then(setCountries).catch(() => setCountries([]));
  }, []);

  // Đóng dropdown khi click ra ngoài
  useEffect(() => {
    function handleClickOutside(e) {
      if (
        isGenreOpen &&
        genreDropdownRef.current &&
        !genreDropdownRef.current.contains(e.target)
      ) {
        setGenreOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () =>
      document.removeEventListener("mousedown", handleClickOutside);
  }, [isGenreOpen]);

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-black/30 backdrop-blur-md border-b border-white/5">
      <nav className="flex items-center h-20 px-4 md:px-12 max-w-screen-2xl mx-auto">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 min-w-[130px]">
          <img src={logo} alt="logo" className="w-11 h-11 object-contain" />
          <span className="font-bold text-2xl text-white leading-none">
            PN <span className="text-yellow-400">Movie</span>
          </span>
        </Link>

        {/* Search bar */}
        <div className="flex-1 flex justify-center px-2">
          <input
            type="text"
            placeholder="Tìm phim, diễn viên..."
            className="w-full max-w-xl px-5 py-2 rounded-full bg-white/10 text-white placeholder-white/60 focus:outline-none focus:ring focus:ring-yellow-400 text-base"
          />
        </div>

        {/* Menu */}
        <div className="hidden lg:flex items-center gap-4 text-sm text-white font-medium">
          <NavLink to="/" className={({ isActive }) =>
            isActive ? "text-yellow-300 font-bold" : "hover:text-yellow-300 transition"
          }>Trang Chủ</NavLink>
          <NavLink to="/category" className="hover:text-yellow-300 transition">Chủ Đề</NavLink>

          {/* Dropdown thể loại */}
          <div className="relative" ref={genreDropdownRef}>
            <button
              onClick={() => setGenreOpen(!isGenreOpen)}
              className="hover:text-yellow-300 transition"
            >
              Thể loại ▾
            </button>
            {isGenreOpen && (
              <div className="absolute left-0 bg-[#22283a]/95 text-white rounded-xl shadow-xl mt-2 min-w-[480px] z-50 p-6 grid grid-cols-1 md:grid-cols-3 gap-x-8 gap-y-1 border border-white/10">
                {genres.map(g => (
                  <Link
                    to={`/genres/${g.id}`}
                    key={g.id}
                    className="px-2 py-1 rounded font-medium hover:bg-yellow-300/10 truncate transition block"
                    onClick={() => setGenreOpen(false)}
                  >
                    {g.name}
                  </Link>
                ))}
              </div>
            )}
          </div>

          <NavLink to="/single" className="hover:text-yellow-300 transition">Phim Lẻ</NavLink>
          <NavLink to="/series" className="hover:text-yellow-300 transition">Phim Bộ</NavLink>

          <div className="relative">
            <button onClick={() => setCountryOpen(!isCountryOpen)} className="hover:text-yellow-300 transition">Quốc gia ▾</button>
            {isCountryOpen && (
              <div className="absolute bg-[#22283a] text-white rounded shadow-lg mt-2 min-w-[160px] z-50 max-h-96 overflow-y-auto">
                {countries.map(c => (
                  <Link to={`/country/${c.id}`} key={c.id} className="block px-4 py-2 hover:bg-yellow-300/10">{c.name}</Link>
                ))}
              </div>
            )}
          </div>
          <NavLink to="/actors" className="hover:text-yellow-300 transition">Diễn viên</NavLink>
          <NavLink to="/schedule" className="hover:text-yellow-300 transition">Lịch chiếu</NavLink>
        </div>

        {/* Đăng nhập */}
        <div className="ml-4">
          <Link to="/login">
            <button className="flex items-center gap-2 px-5 py-2 rounded-full bg-white text-black font-semibold hover:bg-yellow-400 transition">
              <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <circle cx="12" cy="8" r="4" />
                <path d="M6 20v-2a4 4 0 014-4h4a4 4 0 014 4v2" />
              </svg>
              Thành viên
            </button>
          </Link>
        </div>
      </nav>
    </header>
  );
}
