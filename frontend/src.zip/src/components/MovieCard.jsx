import React, { useRef } from "react";
import { Link } from "react-router-dom";
import { PlayCircle, Heart, Info } from "lucide-react";

export default function MovieCard({
  movie,
  genresList,
  sliderRef,
  onHover,
  onLeave,
  isPopup = false,
}) {
  const cardRef = useRef();
  const timerRef = useRef();

  // Lấy tên thể loại
  function getGenreNames(movie, genresList) {
    if (!movie) return [];
    if (Array.isArray(movie.genres) && typeof movie.genres[0] === "string") return movie.genres;
    if (!genresList || !Array.isArray(movie.genres)) return [];
    return movie.genres.map(
      gid =>
        genresList.find(g => g.id === gid)?.name ||
        genresList.find(g => g.genre_id === gid)?.name ||
        gid
    );
  }
  const genreNames = getGenreNames(movie, genresList);

  // Chỉ hover ở dạng card nhỏ, không hover khi là popup
  function handleMouseEnter() {
    if (isPopup) return;
    timerRef.current = setTimeout(() => {
      if (cardRef.current) {
        const rect = cardRef.current.getBoundingClientRect();
        if (
          typeof rect.top === "number" &&
          typeof rect.left === "number" &&
          !isNaN(rect.top) && !isNaN(rect.left)
        ) {
          const sliderScrollLeft = sliderRef?.current?.scrollLeft || 0;
          if (onHover) onHover(movie, { ...rect, sliderScrollLeft });
        }
      }
    }, 1000);
  }
  function handleMouseLeave() {
    if (isPopup) return;
    clearTimeout(timerRef.current);
    if (onLeave) onLeave();
  }

  // Style: Card nhỏ hoặc card popup
  return (
    <div
      className={
        isPopup
          ? "rounded-2xl shadow-2xl p-5 bg-[#181b23]/95 text-white flex flex-col justify-end animate-fadein"
          : "relative group w-[156px] md:w-[180px] shrink-0"
      }
      ref={isPopup ? null : cardRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={
        isPopup
          ? {
              width: 370,
              height: 480,
              boxShadow: "0 16px 48px 0 #000b, 0 0 0 2px #ffd700cc",
              border: "2px solid #ffd700cc",
              position: "relative",
              overflow: "hidden",
              minHeight: 360,
            }
          : { zIndex: 1 }
      }
    >
      {/* Banner/backdrop */}
      <div
        className={
          isPopup
            ? "absolute top-0 left-0 w-full rounded-t-2xl overflow-hidden"
            : "relative overflow-hidden rounded-xl shadow-lg transition"
        }
        style={isPopup ? { height: "44%" } : {}}
      >
        <img
          src={movie.backdrop || movie.poster || "/assets/placeholder.jpg"}
          alt={movie.name || "Không rõ tên"}
          className={
            isPopup
              ? "w-full h-full object-cover opacity-70"
              : "w-full aspect-[2/3] object-cover group-hover:scale-105 transition"
          }
          style={
            isPopup
              ? { objectFit: "cover", height: "100%", width: "100%" }
              : {}
          }
        />
      </div>
      <div className={isPopup ? "relative z-10 pt-[45%]" : "mt-2 min-h-[44px]"}>
        <div className={isPopup ? "font-bold text-lg mb-1" : "font-bold text-base truncate text-white"} title={movie.name || "Không rõ tên"}>
          {movie.name || "Không rõ tên"}
        </div>
        {movie.original_title && movie.original_title !== movie.name && (
          <div className={isPopup ? "text-sm text-yellow-200 mb-2" : "text-xs text-gray-400 truncate"} title={movie.original_title}>{movie.original_title}</div>
        )}
        {isPopup && (
          <>
            <div className="flex gap-2 mb-2 flex-wrap items-center">
              {movie.rating && (
                <span className="bg-yellow-400 text-black text-xs font-bold px-2 py-1 rounded">
                  IMDb {movie.rating}
                </span>
              )}
              {movie.year && (
                <span className="bg-white/20 text-xs px-2 py-1 rounded">{movie.year}</span>
              )}
            </div>
            <div className="flex gap-2 flex-wrap mb-2">
              {genreNames.length > 0
                ? genreNames.map((g, i) => (
                    <span key={i} className="text-xs text-gray-200">{g}</span>
                  ))
                : (
                  <span className="text-xs text-gray-500">Không rõ thể loại</span>
                )}
            </div>
            <div className="text-xs text-gray-300 mb-2 line-clamp-3">
              {movie.description || movie.overview || "Không có mô tả"}
            </div>
            <div className="flex gap-2 mt-2">
              <button className="flex items-center gap-2 px-4 py-2 rounded bg-yellow-400 text-black font-bold">
                <PlayCircle /> Xem ngay
              </button>
              <button className="flex items-center gap-2 px-4 py-2 rounded bg-white/10 text-white">
                <Heart /> Thích
              </button>
              <button className="flex items-center gap-2 px-4 py-2 rounded bg-white/10 text-white">
                <Info /> Chi tiết
              </button>
            </div>
          </>
        )}
      </div>
      {isPopup && (
        <style>{`
          .animate-fadein {
            animation: fadein 0.18s;
          }
          @keyframes fadein {
            from { opacity: 0; transform: scale(1.01);}
            to { opacity: 1; transform: scale(1);}
          }
        `}</style>
      )}
    </div>
  );
}
