import React, { useRef, useState } from "react";
import MovieCard from "./MovieCard";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { createPortal } from "react-dom";

export default function MovieSectionSlider({ title, movies, genresList }) {
  const sliderRef = useRef();

  // Trạng thái card popup và toạ độ
  const [popupMovie, setPopupMovie] = useState(null);
  const [popupRect, setPopupRect] = useState(null);
  const [popupTimeout, setPopupTimeout] = useState(null);

  // Scroll function
  const scroll = (direction) => {
    const scrollAmount = sliderRef.current.offsetWidth * 0.7;
    sliderRef.current.scrollBy({
      left: direction === "left" ? -scrollAmount : scrollAmount,
      behavior: "smooth",
    });
  };

  // Hàm bật popup từ MovieCard (sau khi hover 1s)
  function handleCardHover(movie, rect) {
    setPopupMovie(movie);
    setPopupRect(rect);
  }

  // Hàm clear popup (mouseleave)
  function handleCardHover(movie, rect) {
  // Chỉ nhận rect nếu là số hợp lệ, tránh NaN
  if (
    rect &&
    typeof rect.top === "number" && !isNaN(rect.top) &&
    typeof rect.left === "number" && !isNaN(rect.left)
  ) {
    setPopupMovie(movie);
    setPopupRect(rect);
  }
}
  // Overlay portal cho popup
  const popup =
  popupMovie && popupRect &&
  typeof popupRect.top === "number" &&
  typeof popupRect.left === "number" &&
  !isNaN(popupRect.top) &&
  !isNaN(popupRect.left)
    ? createPortal(
        <div
          className="fixed z-[9999]"
          style={{
            top: Number.isFinite(popupRect.top) ? popupRect.top + window.scrollY : 0,
            left: Number.isFinite(popupRect.left) ? popupRect.left + window.scrollX - (popupRect.sliderScrollLeft || 0) : 0,
            width: 370,
            height: 480,
            pointerEvents: "auto",
          }}
          onMouseLeave={handleCardLeave}
          onMouseEnter={() => {}}
        >
          <MovieCard
            movie={popupMovie}
            genresList={genresList}
            isPopup={true}
          />
        </div>,
        document.body
      )
    : null;

  return (
    <section className="py-8 px-4 max-w-screen-xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl md:text-3xl font-bold text-white drop-shadow">{title}</h2>
        <div className="flex gap-2">
          <button onClick={() => scroll("left")} className="rounded-full bg-white/10 hover:bg-yellow-400 hover:text-black text-white w-10 h-10 flex items-center justify-center transition">
            <ChevronLeft size={24} />
          </button>
          <button onClick={() => scroll("right")} className="rounded-full bg-white/10 hover:bg-yellow-400 hover:text-black text-white w-10 h-10 flex items-center justify-center transition">
            <ChevronRight size={24} />
          </button>
        </div>
      </div>
      <div ref={sliderRef} className="flex gap-6 pb-2 scroll-smooth relative overflow-x-auto no-scrollbar">
        {movies.map(movie => (
          <MovieCard
            key={movie.id}
            movie={movie}
            genresList={genresList}
            sliderRef={sliderRef}
            onHover={handleCardHover}
            onLeave={handleCardLeave}
            isPopup={false}
          />
        ))}
      </div>
      {popup}
    </section>
  );
}
