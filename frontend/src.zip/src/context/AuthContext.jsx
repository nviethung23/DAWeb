import React, { createContext, useContext, useState } from "react";

const AuthContext = createContext();

const USERS = [
  { username: "admin", password: "admin123", role: "admin" }
];

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const data = localStorage.getItem("daweb_user");
    return data ? JSON.parse(data) : null;
  });

  const login = (username, password) => {
    // fake check user
    const found = USERS.find(
      u => u.username === username && u.password === password
    );
    if (found) {
      setUser(found);
      localStorage.setItem("daweb_user", JSON.stringify(found));
      return { success: true, role: found.role };
    }
    return { success: false };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("daweb_user");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
