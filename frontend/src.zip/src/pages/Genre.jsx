import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { discoverMoviesByGenre } from "../services/tmdbService";
import MovieCard from "../components/MovieCard";
import axios from "axios";

function normalizeMovies(list) {
  return list.map(item => ({
    ...item,
    from: "tmdb",
    name: item.title || item.name,
    year: (item.release_date || "").split("-")[0],
    poster: item.poster_path ? "https://image.tmdb.org/t/p/w500" + item.poster_path : "",
  }));
}

export default function GenrePage() {
  const { id } = useParams();
  const [movies, setMovies] = useState([]);
  const [genreName, setGenreName] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      try {
        const [genreRes, movieRes] = await Promise.all([
          axios.get("http://localhost:5000/api/tmdb/genres"),
          discoverMoviesByGenre(id)
        ]);

        const genre = genreRes.data.genres.find(g => String(g.id) === String(id));
        setGenreName(genre?.name || `Thể loại #${id}`);

        setMovies(normalizeMovies(movieRes));
      } catch {
        setMovies([]);
        setGenreName(`Thể loại #${id}`);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [id]);

  return (
    <div className="container mx-auto px-4 py-8 text-white min-h-screen bg-[#0f0f1b]">
      <h2 className="text-2xl font-bold mb-6">Thể loại: {genreName}</h2>
      {loading ? (
        <div className="text-center py-12 text-gray-400">Đang tải phim...</div>
      ) : movies.length === 0 ? (
        <div className="text-center py-12 text-gray-400">Không có phim nào trong thể loại này.</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {movies.map(movie => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      )}
    </div>
  );
}
