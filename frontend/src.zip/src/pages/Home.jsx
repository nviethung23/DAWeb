import React, { useEffect, useRef, useState } from "react";
import { fetchAllMovies } from "../utils/fetchAllMovies";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import MovieSectionSlider from "../components/MovieSectionSlider";
import HeroBannerContainer from "../components/HeroBannerContainer";
import logo from "../assets/logo.png";
import CategorySection from "../components/CategorySection";
import AnimeSpotlightSection from "../components/AnimeSpotlightSection";

export default function Home() {
  const [movies, setMovies] = useState([]);
  const [genres, setGenres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentHeroIndex, setCurrentHeroIndex] = useState(0);
  const autoSlideRef = useRef();
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchAll() {
      setLoading(true);
      try {
        // Lấy genres và all movies song song
        const [genresRes, allMovies] = await Promise.all([
          axios.get("http://localhost:5000/api/tmdb/genres"),
          fetchAllMovies()
        ]);
        setGenres(genresRes.data.genres || []);
        setMovies(allMovies);
      } catch (e) {
        setGenres([]);
        setMovies([]);
      } finally {
        setLoading(false);
      }
    }
    fetchAll();
  }, []);

function markSource(list) {
  return list
    .map(item => {
      const genreId = item.genre_ids?.[0];
      const genre = genres.find(g => g.id === genreId);
      return {
        ...item,
        name: item.title || item.name || "Không rõ tên", // Đảm bảo có tên
        year: (item.release_date || "").split("-")[0],
        poster: item.poster_path
          ? "https://image.tmdb.org/t/p/w500" + item.poster_path
          : item.poster || "/assets/placeholder.jpg", // Đảm bảo luôn có ảnh poster
        backdrop: item.backdrop_path
          ? "https://image.tmdb.org/t/p/original" + item.backdrop_path
          : "",
        description: item.overview || "",
        rating: item.vote_average,
        genres: item.genre_ids || [],
        original_language: item.original_language,
        id: item.id,
        category: genre?.name || null
      };
    })
    .filter(
      m =>
        m.description &&
        m.description.length > 30 &&
        m.backdrop &&
        m.poster // poster luôn có nhờ đoạn trên
    );
}
  // Slide tự động cho HeroBanner
  useEffect(() => {
    if (!movies.length) return;
    const featuredMovies = uniqueMovies.slice(0, 6);
    autoSlideRef.current = setInterval(() => {
      setCurrentHeroIndex(prev => (prev + 1) % featuredMovies.length);
    }, 30000);
    return () => clearInterval(autoSlideRef.current);
    // eslint-disable-next-line
  }, [movies]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white relative overflow-hidden">
        <div className="absolute w-[300px] h-[300px] rounded-full bg-yellow-500/20 blur-3xl animate-ping"></div>
        <img
          src={logo}
          alt="PN Movie"
          className="w-24 h-24 object-contain animate__animated animate__pulse animate__infinite"
        />
        <div className="text-xl mt-6 tracking-wide font-semibold animate__animated animate__fadeIn">
          Đang tải tất cả phim...
        </div>
      </div>
    );
  }

  // Chuẩn hóa unique movies
  const uniqueMovies = Array.from(
    new Map(markSource(movies).map(m => [m.id, m])).values()
  );
  const featuredMovies = uniqueMovies.slice(0, 6);
  const featuredMovie = featuredMovies[currentHeroIndex];
  const featuredIDs = new Set(featuredMovies.map(m => m.id));
  const gridMovies = uniqueMovies.filter(m => !featuredIDs.has(m.id));

  // Anime/Hoạt hình = genre_ids gồm 16
  const animeMovies = uniqueMovies
    .filter(
      m =>
        (Array.isArray(m.genre_ids) && m.genre_ids.includes(16))
    )
    .slice(0, 14);

  const vietMovies = uniqueMovies
    .filter(m => m.original_language === "vi")
    .slice(0, 12);

  const koreaMovies = uniqueMovies
    .filter(m => m.original_language === "ko")
    .slice(0, 12);

  return (
    <div className="bg-[#0f0f1b] min-h-screen text-white">
      {featuredMovie && (
        <div className="relative">
          <HeroBannerContainer movie={featuredMovie} />
          <div className="absolute z-20 flex gap-2 right-8 top-[75%]">
            {featuredMovies.map((m, idx) => (
              <button
                key={idx}
                className={`w-14 h-8 border-2 rounded-full overflow-hidden transition-all duration-300 ${
                  idx === currentHeroIndex
                    ? "border-yellow-500 scale-110"
                    : "border-gray-600 opacity-60 hover:opacity-100"
                }`}
                onClick={() => setCurrentHeroIndex(idx)}
              >
                <img
                  src={m.poster}
                  alt="thumb"
                  className="w-full h-full object-cover rounded-full"
                />
              </button>
            ))}
          </div>
        </div>
      )}

      <CategorySection />

      <MovieSectionSlider
        title="Phim mới cập nhật"
        movies={uniqueMovies.slice(6, 18)}
        genresList={genres}
      />
      <MovieSectionSlider
        title="IMDb cao nhất"
        movies={[...uniqueMovies].sort((a, b) => b.rating - a.rating).slice(0, 12)}
        genresList={genres}
      />
      
      <AnimeSpotlightSection animeList={animeMovies} />
      <MovieSectionSlider title="Phim Việt Nam" movies={vietMovies} genresList={genres} />
      <MovieSectionSlider title="Phim Hàn Quốc" movies={koreaMovies} genresList={genres} />

      {gridMovies.length === 0 && !loading && (
        <div className="text-center text-gray-400 my-20">
          Không tìm thấy phim nào để hiển thị.
        </div>
      )}
    </div>
  );
}
