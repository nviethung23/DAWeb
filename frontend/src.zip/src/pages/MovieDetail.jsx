import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";

export default function MovieDetail() {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  const [loading, setLoading] = useState(true);
  const [trailerUrl, setTrailerUrl] = useState("");

  useEffect(() => {
    async function fetchData() {
      try {
        // 1. Kiểm tra phim backend
        const backendRes = await axios.get(`http://localhost:5000/api/movies`);
        const found = backendRes.data.find(m => String(m.id) === String(id));
        if (found) {
          setMovie({ ...found, from: "backend" });
          setTrailerUrl(found.trailer || "");
          setLoading(false);
          return;
        }

        // 2. Nếu không có → lấy từ TMDb
        const tmdbRes = await axios.get(`http://localhost:5000/api/tmdb/movie/${id}`);
        const m = tmdbRes.data;
        const movieObj = {
          ...m,
          from: "tmdb",
          name: m.title || m.name,
          year: (m.release_date || m.first_air_date || "").split("-")[0],
          poster: m.poster_path ? "https://image.tmdb.org/t/p/w500" + m.poster_path : "",
          description: m.overview,
          genres: m.genres?.map(g => g.name).join(", "),
          rating: m.vote_average,
        };
        setMovie(movieObj);

        // 3. Lấy trailer YouTube từ TMDb
        const videoRes = await axios.get(`http://localhost:5000/api/tmdb/movie/${id}/videos`);
        const trailer = videoRes.data.results?.find(
          v => v.site === "YouTube" && v.type === "Trailer"
        ) || videoRes.data.results?.find(
          v => v.site === "YouTube"
        );
        if (trailer) {
          setTrailerUrl("https://www.youtube.com/embed/" + trailer.key);
        }
      } catch (err) {
        console.error("Lỗi khi tải phim:", err);
        setMovie(null);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [id]);

  if (loading) return <div className="text-center py-12">Đang tải thông tin phim...</div>;
  if (!movie) return <div className="text-center py-12 text-red-500">Không tìm thấy phim.</div>;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <Link to="/" className="text-blue-500 hover:underline">← Về trang chủ</Link>

      <h2 className="text-2xl font-bold mt-4 mb-2">
        {movie.name} {movie.year ? `(${movie.year})` : ""}
      </h2>

      <div className="text-sm text-gray-400 mb-3">
        {movie.genres && <span>🎬 {movie.genres} </span>}
        {movie.rating && <span>⭐ {movie.rating.toFixed(1)}/10</span>}
      </div>

      <img src={movie.poster} alt={movie.name} className="w-64 rounded mb-4 shadow" />

      <div className="mb-4 text-base text-gray-200">{movie.description}</div>

      {/* 🎥 Trailer */}
      {trailerUrl && (
        <div className="mb-6">
          <div className="font-semibold text-white mb-2">🎞 Trailer:</div>
          <iframe
            src={trailerUrl}
            width="100%"
            height="400"
            allow="autoplay; encrypted-media"
            allowFullScreen
            className="rounded shadow"
          ></iframe>
        </div>
      )}

      {/* 📺 Watch movie */}
      {movie.watch_url && (
        <div className="mb-6">
          <div className="font-semibold text-white mb-2">🎬 Xem phim:</div>
          <iframe
            src={movie.watch_url.replace("/view", "/preview")}
            width="100%"
            height="500"
            allow="autoplay; encrypted-media"
            allowFullScreen
            className="rounded shadow"
          ></iframe>
        </div>
      )}

      {/* 🔶 Nếu là phim backend mà không có trailer */}
      {movie.from === "backend" && !trailerUrl && !movie.watch_url && (
        <div className="text-center text-sm text-orange-600 bg-orange-100 rounded p-4">
          (Phim này được thêm thủ công – chưa có trailer hoặc link xem thật)
        </div>
      )}

      {/* 🔶 Nếu là phim TMDb không có trailer */}
      {movie.from === "tmdb" && !trailerUrl && (
        <div className="text-gray-500 text-sm text-center">Không tìm thấy trailer YouTube</div>
      )}
    </div>
  );
}
