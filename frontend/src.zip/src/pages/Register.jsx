import React from "react";

export default function Register() {
  // Demo: Không triển khai register thật, chỉ báo admin dùng tài khoản có sẵn
  return (
    <div className="flex justify-center items-center min-h-[60vh]">
      <div className="bg-white p-6 rounded-xl shadow-lg max-w-md w-full text-center">
        <h2 className="text-xl font-bold mb-4">Đăng ký (Demo)</h2>
        <div>
          Hệ thống hiện tại chỉ cho phép đăng nhập với tài khoản có sẵn.<br />
          <span className="font-bold">Admin: admin / admin123</span>
        </div>
      </div>
    </div>
  );
}
