import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const navigate = useNavigate();

  function handleSubmit(e) {
    e.preventDefault();
    const res = login(username, password);
    if (res.success) {
      if (res.role === "admin") navigate("/admin");
      else navigate("/");
    } else {
      setErr("Tài khoản hoặc mật khẩu sai!");
    }
  }

  return (
    <div className="flex justify-center items-center min-h-[70vh]">
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-lg w-full max-w-md">
        <h2 className="text-xl font-bold mb-4">Đăng nhập</h2>
        <div className="mb-3">
          <input value={username} onChange={e => setUsername(e.target.value)}
            placeholder="Tài khoản" className="border px-3 py-2 rounded w-full" />
        </div>
        <div className="mb-3">
          <input type="password" value={password} onChange={e => setPassword(e.target.value)}
            placeholder="Mật khẩu" className="border px-3 py-2 rounded w-full" />
        </div>
        {err && <div className="text-red-600 mb-2">{err}</div>}
        <button className="bg-blue-600 text-white px-4 py-2 rounded w-full">Đăng nhập</button>
      </form>
    </div>
  );
}
