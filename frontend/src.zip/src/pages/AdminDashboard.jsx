import React, { useEffect, useState, useRef } from "react";
import AdminSidebar from "../components/AdminSidebar";

const API_URL = "http://localhost:5000/api/movies";
const VIDEO_URL = "http://localhost:5000/uploads/";

export default function AdminDashboard() {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [message, setMessage] = useState("");
  const [form, setForm] = useState({
    name: "",
    year: "",
    description: "",
    poster: "",
    trailer: ""
  });
  const [videoFile, setVideoFile] = useState(null);
  const videoInputRef = useRef();

  // Lấy danh sách phim
  const fetchMovies = () => {
    setLoading(true);
    fetch(API_URL)
      .then(res => res.json())
      .then(data => {
        setMovies(data);
        setLoading(false);
      })
      .catch(() => {
        setErr("Không thể lấy danh sách phim.");
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchMovies();
  }, []);

  // Xử lý form thêm phim
  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleVideoChange = e => {
    setVideoFile(e.target.files[0]);
  };

  const handleAddMovie = async e => {
    e.preventDefault();
    setErr("");
    setMessage("");
    if (!form.name || !form.year) {
      setErr("Nhập đủ tên và năm phát hành!");
      return;
    }
    const formData = new FormData();
    Object.entries(form).forEach(([k, v]) => formData.append(k, v));
    if (videoFile) formData.append("video", videoFile);
    try {
      const res = await fetch(API_URL, {
        method: "POST",
        body: formData
      });
      if (!res.ok) throw new Error();
      setForm({ name: "", year: "", description: "", poster: "", trailer: "" });
      setVideoFile(null);
      if (videoInputRef.current) videoInputRef.current.value = "";
      setMessage("Đã thêm phim thành công!");
      fetchMovies();
    } catch {
      setErr("Lỗi khi thêm phim!");
    }
  };

  // Xóa phim
  const handleDelete = async (id) => {
    if (!window.confirm("Xác nhận xoá phim này?")) return;
    setErr(""); setMessage("");
    try {
      const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      setMessage("Đã xoá phim!");
      fetchMovies();
    } catch {
      setErr("Lỗi khi xoá phim!");
    }
  };

  return (
    <div className="flex gap-8 min-h-[70vh]">
      <AdminSidebar />
      <div className="flex-1 py-6">
        <h1 className="text-2xl font-bold mb-4">Quản lý phim riêng</h1>
        <div className="bg-white p-4 rounded shadow mb-8">
          <h2 className="font-bold mb-2">Thêm phim mới</h2>
          <form onSubmit={handleAddMovie} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              name="name"
              value={form.name}
              onChange={handleChange}
              className="border px-2 py-1 rounded"
              placeholder="Tên phim"
              required
            />
            <input
              name="year"
              value={form.year}
              onChange={handleChange}
              className="border px-2 py-1 rounded"
              placeholder="Năm phát hành"
              required
            />
            <input
              name="poster"
              value={form.poster}
              onChange={handleChange}
              className="border px-2 py-1 rounded"
              placeholder="Link poster (hoặc để trống nếu upload video)"
            />
            <input
              name="trailer"
              value={form.trailer}
              onChange={handleChange}
              className="border px-2 py-1 rounded"
              placeholder="Link trailer Youtube (nếu có)"
            />
            <textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              className="border px-2 py-1 rounded md:col-span-2"
              placeholder="Mô tả phim"
              rows={2}
            />
            <input
              type="file"
              accept="video/*"
              onChange={handleVideoChange}
              ref={videoInputRef}
              className="md:col-span-2"
            />
            <button
              className="bg-green-600 text-white px-4 py-2 rounded md:col-span-2"
              type="submit"
            >
              Thêm phim
            </button>
          </form>
          {err && <div className="text-red-600 mt-2">{err}</div>}
          {message && <div className="text-green-600 mt-2">{message}</div>}
        </div>
        <h2 className="font-bold mb-3">Danh sách phim</h2>
        {loading ? (
          <div>Đang tải...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm bg-white shadow rounded">
              <thead>
                <tr>
                  <th className="p-2 border">Tên phim</th>
                  <th className="p-2 border">Năm</th>
                  <th className="p-2 border">Poster</th>
                  <th className="p-2 border">Video</th>
                  <th className="p-2 border">Xoá</th>
                </tr>
              </thead>
              <tbody>
                {movies.map(m => (
                  <tr key={m.id}>
                    <td className="border px-2">{m.name}</td>
                    <td className="border px-2">{m.year}</td>
                    <td className="border px-2">
                      {m.poster ? (
                        <img src={m.poster} alt="" className="w-14 rounded" />
                      ) : (
                        <span className="italic text-gray-400">Không có</span>
                      )}
                    </td>
                    <td className="border px-2">
                      {m.video_path ? (
                        <video controls width={100}>
                          <source src={VIDEO_URL + m.video_path} />
                        </video>
                      ) : (
                        <span className="italic text-gray-400">Không có</span>
                      )}
                    </td>
                    <td className="border px-2">
                      <button
                        onClick={() => handleDelete(m.id)}
                        className="bg-red-600 text-white px-3 py-1 rounded"
                      >
                        Xoá
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {movies.length === 0 && (
              <div className="text-gray-500 italic p-4">Chưa có phim riêng nào.</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
