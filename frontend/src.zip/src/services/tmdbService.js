import axios from "axios";

const API_BASE = "http://localhost:5000/api/tmdb";

export async function getGenres() {
  const res = await axios.get(`${API_BASE}/genres`);
  return res.data.genres || [];
}

export async function getCountries() {
  const res = await axios.get(`${API_BASE}/countries`);
  return res.data.countries || [];
}

export async function getPopularMovies(page = 1) {
  const res = await axios.get(`${API_BASE}/popular?page=${page}`);
  return res.data.results || [];
}

export async function getTopRatedMovies() {
  const res = await axios.get(`${API_BASE}/top-rated`);
  return res.data.results || [];
}

export async function getMovieDetail(id) {
  const res = await axios.get(`${API_BASE}/movie/${id}`);
  return res.data;
}

export async function getMovieVideos(id) {
  const res = await axios.get(`${API_BASE}/movie/${id}/videos`);
  return res.data.results || [];
}

export async function discoverMoviesByGenre(genreId) {
  const res = await axios.get(`${API_BASE}/discover?with_genres=${genreId}`);
  return res.data.results || [];
}

export async function searchMovies(query) {
  const res = await axios.get(`${API_BASE}/search?query=${query}`);
  return res.data.results || [];
}

export async function getPopularActors() {
  const res = await axios.get(`${API_BASE}/actors`);
  return res.data.results || [];
}
